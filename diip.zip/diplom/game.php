<?php 
session_start();
 
include('webclass.php');
$sc= new SiteClass;

if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}


if(!empty($_POST['new_card_item'])){
    $item_id=htmlspecialchars($_GET['id']);

     $sc->add_to_card($_SESSION['id'],$item_id);
}
if(!empty($_POST['new_wishlist_item'])){
     $item_id=htmlspecialchars($_GET['id']);
    $sc->add_to_wishlist($_SESSION['id'],$item_id);

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <script src="assets/js/color-modes.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
     <!-- owl -->
     <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.css">
    <!--  -->
    <script src="ninjaslide/ninja-slider.js"></script>
    <link rel="stylesheet" href="ninjaslide/ninja-slider.css">
 
</head>
<body>
 <div class="site_wrap">
     <div id="root"></div>
 <?php 
    if(!empty($_SESSION['status'])){
        require_once("MVC/header_admin.php");
    }else{
        require_once("MVC/header.php");
    }
      ?>
       <div class="intro_text" style="text-align: center;">
    <h4>Страница товара</h4>
    <p>На этой странице можно подробно узнать всю информацию о товаре и добавить его в корзину или список желаемого</p>
    </div>
    <div class="game_wrap">
        <?php $sc->gameinfo(); ?>
            <div class='screenshot_courosel'></div>
    </div>
    <div class="sales_games border-bottom">
                <h1>Скидки</h1>
            <div class="owl-carousel"><?php $sc->game_sales(); ?></div>
    </div>  
    <?php require_once("MVC/footer.php"); ?>
    </div>
 <script src="js/jquery-3.7.1.js"></script>
<script src="jquery.min.js"></script>
<script src="owlcarousel/owl.carousel.min.js"></script>
<script>
    $(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
 </script>
 <script>
  $('.owl-carousel').owlCarousel({
    margin:10,
    loop:true,
    autoWidth:true,
    items:4,
    nav:false,
    dots:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
})
 </script>
 
</body>
</html>