-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 13, 2024 at 07:53 AM
-- Server version: 5.7.24
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diplom`
--

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` int(11) NOT NULL,
  `gender` varchar(56) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `gender`) VALUES
(1, 'Экшен'),
(2, 'Приключения'),
(3, 'Ролевые'),
(4, 'Стратегии'),
(5, 'Гонки');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(3) NOT NULL,
  `name` varchar(56) NOT NULL,
  `description` text NOT NULL,
  `year` int(4) NOT NULL,
  `cost` int(6) NOT NULL,
  `sale` int(6) NOT NULL,
  `gender` int(3) NOT NULL,
  `mode` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `description`, `year`, `cost`, `sale`, `gender`, `mode`) VALUES
(15, 'Nier_Automata', 'Завязка сюжета игры Nier: Automata происходит на планете Земля, которая была захвачена инопланетными машинами, создавшими механическую форму жизни. Эти машины используют колоссальную военную мощь, чтобы захватить всю планету. Человечество вынуждено эвакуироваться на Луну, но некоторые отважные повстанцы продолжают бороться против захватчиков.', 2017, 1200, 1800, 1, 1),
(16, 'Cyberpunk 2077', 'Завязка сюжета в игре Cyberpunk 2077 происходит в Найт-Сити, одном из последних великих мегаполисов планеты. Город разделён между разными группировками, находящимися по разную сторону закона. В этом хаосе Найт-Сити становится маяком надежды для миллионов беженцев, стремящихся вернуться к комфортной жизни.\r\nГлавный герой, V, — изгой, кибернетически улучшенный городской наёмник без хозяев и авторитетов. Ему поручают важное задание — украсть ценный биочип, но во время выполнения задания защитная оболочка чипа повреждается. Чтобы сохранить чип и не провалить миссию, V принимает тяжёлое решение — вживить чип себе в мозг.\r\nОказалось, что в чипе хранится оцифрованная личность Джонни Сильверхенда, рокбоя, погибшего более 100 лет назад. Теперь Джонни хочет уничтожить корпорацию «Арасака», создавшую этот биочип, и готов завладеть телом V, чтобы осуществить свою месть.', 2020, 1800, 3000, 1, 1),
(17, 'Bioshock Infinite', 'В игре Bioshock Infinite завязка сюжета начинается в 1912 году. Главный герой, Букер ДеВитт, после трагического события решает пройти обряд крещения и изменить свою жизнь. Он становится Захари Комстоком и создаёт утопический город Колумбию. Однако из-за ошибки в создании порталов дочь Букера, Элизабет, оказывается в другом измерении.\r\nСпустя 20 лет Букер отправляется в Колумбию, чтобы найти и вернуть Элизабет. На своём пути он сталкивается с гениальными учёными Розалиндой Лютес и Иеремией Финком, которые создали порталы для перемещения между измерениями. Они пытаются остановить Комстока, но погибают. Их сознание сливается в близнецов Лютес, которые помогают Букеру в его поисках.\r\nБукер похищает Элизабет, но на их пути возникает множество препятствий. Элизабет использует свои способности для управления измерениями, чтобы обойти трудности. В процессе игры Букер узнаёт правду о своём прошлом и о том, что он и Комсток — один и тот же человек, который пошёл разными путями.', 2013, 400, 800, 1, 1),
(19, 'Call of Duty Black Ops 2', 'Завязка сюжета игры Black Ops 2 происходит в 2025 году. Главный герой, Дэвид Мейсон, сын Алекса Мейсона из первой части игры, пытается раскрыть заговор, связанный с дефицитом редких ископаемых, из-за которого началась вымышленная холодная война между Китаем и США. В ходе расследования Дэвид обнаруживает, что за всем этим стоит Рауль Менендес, главный злодей игры.', 2012, 1200, 1700, 1, 3),
(20, 'Call of Duty Modern Warfare 2', 'События Call of Duty: Modern Warfare 2 разворачиваются в 2022 году. Капитан Джон Прайс собирает отряд для борьбы с террористами по всему миру. Главные герои — капитан Прайс, Кайл Гэррик, Джон «Соуп» Мактавиш и Саймон «Гоуст» Райли. Они действуют при поддержке ЦРУ и американских военных. Главный злодей — иранский боевик Хассан Зиани, который спонсирует террористов и угрожает Вашингтону баллистической ракетой.', 2022, 2400, 3300, 1, 3),
(21, 'Dragons Dogma 2', 'Действие игры Dragons Dogma 2 разворачивается в параллельном мире, где судьба главного героя, Возникшего, связана с драконом, который украл его сердце. Возникший должен вернуть своё сердце дракону, сражаясь с ним или жертвуя своей возлюбленной. В зависимости от выбора игрока, Возникший может стать следующим правителем человеческого королевства Вермунд или драконом, которому поручено найти и выбрать следующего Возникшего.', 2024, 2800, 3600, 3, 1),
(23, 'Dark Souls Remastered', 'Завязка сюжета в игре Dark Souls 1 происходит в мире, где некогда царило вечное равновесие между светом и тьмой. Однако после появления Первого Пламени, источника света и жизни, мир изменился. Великие драконы, бывшие хранителями этого равновесия, пали, и их место заняли боги.\r\nОдин из этих богов, Гвин, стал повелителем света и защитником человечества. Но со временем люди начали злоупотреблять силой тёмной души, которая была скрыта в глубинах земли. Это привело к появлению Мануса, жестокого существа, стремящегося уничтожить всё живое.\r\nГлавный герой, избранный мёртвец, должен пройти через множество испытаний, чтобы победить Мануса и восстановить равновесие между светом и тьмой.', 2018, 1000, 1800, 2, 1),
(24, 'Dark Souls 3', 'В игре Dark Souls 3 сюжет начинается с того, что когда-то давно Повелители Пепла были хранителями мира. Однажды человечество оказалось на грани катастрофы, и только Повелители Пепла могли предотвратить беду, пожертвовав собой. Однако они решили не помогать людям и разбежались по своим владениям, ожидая конца света.\r\nВ последний день угасающего мира из могилы поднимается бесстрашный герой с проклятием тёмной метки, не позволяющей ему умирать. Он становится покровителем слабого и беззащитного мира и решает отомстить Повелителям, возложив их пепел на алтари Храма огня, чтобы продлить бытие мира.', 2016, 1400, 2000, 2, 1),
(26, 'Final Fantasy 7', 'Завязка сюжета игры Final Fantasy VII разворачивается в городе Мидгар, где достижения промышленности мирно сосуществуют с магией и монстрами. Главный герой — Клауд Страйф, бывший военный, а ныне наёмник и член экотеррористической группировки Avalanche. Их цель — уничтожить реактор энергетической компании Shinra в Мидгаре, которая выкачивает жизненно важный ресурс из недр планеты.', 2018, 2400, 1800, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mode`
--

CREATE TABLE `mode` (
  `id` int(3) NOT NULL,
  `item_id` int(3) NOT NULL,
  `gamemod` varchar(56) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mode`
--

INSERT INTO `mode` (`id`, `item_id`, `gamemod`) VALUES
(1, 1, 'Одиночная игра'),
(2, 1, 'Локальный коорператив'),
(3, 1, 'Онлайн');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(3) NOT NULL,
  `email` varchar(120) NOT NULL,
  `user_id` int(3) NOT NULL,
  `order_items` text NOT NULL,
  `cost` int(6) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `email`, `user_id`, `order_items`, `cost`, `date`) VALUES
(14, 'zxc@gmail.com', 2, '15,16,26', 5000, '2024-06-13 01:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(3) NOT NULL,
  `item_id` int(3) NOT NULL,
  `images_folder` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `item_id`, `images_folder`) VALUES
(2, 15, 'Nier_Automata_images'),
(3, 16, 'Cyberpunk 2077_images'),
(4, 17, 'Bioshock Infinite_images'),
(6, 19, 'Call of Duty Black Ops 2_images'),
(7, 20, 'Call of Duty Modern Warfare 2_images'),
(8, 21, 'Dragons Dogma 2_images'),
(10, 23, 'Dark Souls Remastered_images'),
(11, 24, 'Dark Souls 3_images'),
(13, 26, 'Final_Fantasy_7_images');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(3) NOT NULL,
  `login` varchar(32) NOT NULL,
  `passworld` varchar(32) NOT NULL,
  `reg_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `passworld`, `reg_date`) VALUES
(2, 'user01', 'b75705d7e35e7014521a46b532236ec3', '2024-05-23 13:36:44'),
(3, 'user2020', '7a4f994cbc99a38463b415fc13310b89', '2024-05-23 13:37:20'),
(4, 'user20', '10880c7f4e4209eeda79711e1ea1723e', '2024-05-26 14:32:52'),
(5, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2024-05-26 15:18:38'),
(6, 'user11', '03aa1a0b0375b0461c1b8f35b234e67a', '2024-06-12 23:59:28');

-- --------------------------------------------------------

--
-- Table structure for table `user_card`
--

CREATE TABLE `user_card` (
  `id` int(11) NOT NULL,
  `user_id` int(3) NOT NULL,
  `card_item` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_card`
--

INSERT INTO `user_card` (`id`, `user_id`, `card_item`) VALUES
(27, 2, 26),
(32, 6, 19),
(33, 2, 16),
(34, 2, 15);

-- --------------------------------------------------------

--
-- Table structure for table `user_wishlist`
--

CREATE TABLE `user_wishlist` (
  `id` int(3) NOT NULL,
  `user_id` int(3) NOT NULL,
  `item_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_wishlist`
--

INSERT INTO `user_wishlist` (`id`, `user_id`, `item_id`) VALUES
(3, 2, 23),
(4, 2, 16),
(5, 2, 26),
(6, 2, 24),
(10, 2, 20),
(11, 2, 15),
(13, 2, 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mode`
--
ALTER TABLE `mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_card`
--
ALTER TABLE `user_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_wishlist`
--
ALTER TABLE `user_wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `mode`
--
ALTER TABLE `mode`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_card`
--
ALTER TABLE `user_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user_wishlist`
--
ALTER TABLE `user_wishlist`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
