<?php 
 
class SiteClass {
    
	private $conn = ""; 	
 
	public function __construct(){
	$this->conn=mysqli_connect("localhost","root","root","diplom");
	}	
    public function user_nav_bar(){
     echo"   <div class=\"top-menu-wrap\">
     <div class=\"top-menu-items\">
         <div class=\"left\">
         <div class=\"item\"> </div>
         <svg width=\"305.000000\" height=\"62.000000\" viewBox=\"0 0 305 62\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">
         <desc>
                 Created with Pixso.
         </desc>
         <defs>
             <clipPath id=\"clip6_3\">
                 <rect id=\"memory-gamepad-down-left\" width=\"37.846153\" height=\"41.000000\" transform=\"translate(-0.230713 0.000000)\" fill=\"white\" fill-opacity=\"0\"/>
             </clipPath>
         </defs>
         <path id=\"GSHOP\" d=\"M67.95 17.17L63.11 17.17C62.27 14.4 60.12 12.71 56.97 12.71C52.73 12.71 49.68 15.98 49.68 21.88C49.68 27.81 52.69 31.09 57.07 31.09C61 31.09 63.5 28.73 63.58 25L57.54 25L57.54 21.29L68.17 21.29L68.17 24.44C68.17 31.19 63.53 35.36 57.05 35.36C49.82 35.36 44.91 30.21 44.91 21.93C44.91 13.49 50.05 8.45 56.91 8.45C62.69 8.45 67.15 12.04 67.95 17.17ZM91.55 16.01L86.99 16.01C86.74 13.79 84.88 12.47 82.05 12.47C79.09 12.47 77.32 13.91 77.31 15.88C77.28 18.07 79.6 18.97 81.76 19.49L84.21 20.1C88.15 21.04 91.89 23.1 91.91 27.65C91.89 32.26 88.25 35.39 81.98 35.39C75.88 35.39 72 32.46 71.81 27.26L76.48 27.26C76.67 30.01 78.97 31.34 81.93 31.34C85.03 31.34 87.15 29.84 87.16 27.6C87.15 25.57 85.28 24.69 82.46 23.97L79.48 23.21C75.18 22.09 72.5 19.94 72.5 16.18C72.49 11.55 76.62 8.45 82.12 8.45C87.69 8.45 91.46 11.59 91.55 16.01ZM134.27 8.45C141.14 8.45 146.31 13.44 146.31 21.91C146.31 30.36 141.14 35.36 134.27 35.36C127.39 35.36 122.24 30.35 122.24 21.91C122.24 13.44 127.39 8.45 134.27 8.45ZM100.87 35L96.13 35L96.13 8.81L100.87 8.81L100.87 19.9L113 19.9L113 8.81L117.76 8.81L117.76 35L113 35L113 23.88L100.87 23.88L100.87 35ZM155.54 35L150.81 35L150.81 8.81L160.62 8.81C166.64 8.81 169.85 12.49 169.85 17.48C169.85 22.51 166.61 26.14 160.56 26.14L155.54 26.14L155.54 35ZM134.27 31.09C138.55 31.09 141.53 27.86 141.53 21.91C141.53 15.95 138.55 12.71 134.27 12.71C130.02 12.71 127.01 15.95 127.01 21.91C127.01 27.86 130.02 31.09 134.27 31.09ZM155.54 12.78L155.54 22.25L159.92 22.25C163.44 22.25 165.02 20.26 165.02 17.48C165.02 14.69 163.44 12.78 159.89 12.78L155.54 12.78Z\" fill=\"#FFFFFF\" fill-opacity=\"1.000000\" fill-rule=\"evenodd\"/>
         <g clip-path=\"url(#clip6_3)\">
             <path id=\"path\" d=\"M23.85 1.86L23.85 3.72L25.57 3.72L25.57 13.04L34.17 13.04L34.17 14.9L35.89 14.9L35.89 26.09L34.17 26.09L34.17 27.95L25.57 27.95L25.57 37.27L23.85 37.27L23.85 39.13L13.53 39.13L13.53 37.27L11.81 37.27L11.81 27.95L3.2 27.95L3.2 26.09L1.48 26.09L1.48 14.9L3.2 14.9L3.2 13.04L11.81 13.04L11.81 3.72L13.53 3.72L13.53 1.86L23.85 1.86ZM11.81 16.77L4.93 16.77L4.93 24.22L11.81 24.22L11.81 16.77ZM15.25 27.95L15.25 35.4L22.13 35.4L22.13 27.95L15.25 27.95Z\" fill=\"#44FF00\" fill-opacity=\"1.000000\" fill-rule=\"nonzero\"/>
             <path id=\"path\" d=\"M23.85 3.72L25.57 3.72L25.57 13.04L34.17 13.04L34.17 14.9L35.89 14.9L35.89 26.09L34.17 26.09L34.17 27.95L25.57 27.95L25.57 37.27L23.85 37.27L23.85 39.13L13.53 39.13L13.53 37.27L11.81 37.27L11.81 27.95L3.2 27.95L3.2 26.09L1.48 26.09L1.48 14.9L3.2 14.9L3.2 13.04L11.81 13.04L11.81 3.72L13.53 3.72L13.53 1.86L23.85 1.86L23.85 3.72ZM4.93 16.77L4.93 24.22L11.81 24.22L11.81 16.77L4.93 16.77ZM15.25 35.4L22.13 35.4L22.13 27.95L15.25 27.95L15.25 35.4Z\" stroke=\"#44FF00\" stroke-opacity=\"1.000000\" stroke-width=\"0.000640\"/>
         </g>
     </svg>

         </div>
          
         <div class=\"container justify-content-center\">
         <form action=\"\" method=\"post\">

         <div class=\"row\">

                 <div class=\"col-md-8\">
                     
                     <div class=\"input-group mb-3\">
                          
                         <input type=\"text\" class=\"form-control input-text\" placeholder=\"Search products....\" aria-label=\"Recipient's username\" aria-describedby=\"basic-addon2\" required>
                             <div class=\"input-group-append\">
                                 <button class=\"btn btn-outline-warning btn-lg\" type=\"submit\"><i class=\"fa fa-search\">
                                 <svg width=\"32px\" height=\"32px\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><g id=\"SVGRepo_bgCarrier\" stroke-width=\"0\"></g><g id=\"SVGRepo_tracerCarrier\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></g><g id=\"SVGRepo_iconCarrier\"> <path d=\"M15.7955 15.8111L21 21M18 10.5C18 14.6421 14.6421 18 10.5 18C6.35786 18 3 14.6421 3 10.5C3 6.35786 6.35786 3 10.5 3C14.6421 3 18 6.35786 18 10.5Z\" stroke=\"#ffffff\" stroke-width=\"0.984\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path> </g></svg>
                                 </i></button>
                             </div>
                        
                            
                     </div>
                     
                 </div>        
                     
         </div>
         
         </form>
     </div>
    
         <div class=\"right\">
            
   
             <div class=\"item\">
                 <a href=\"profile.php\">
                 <div class=\"icon\">
                 <svg width=\"23.000000\" height=\"22.000000\" viewBox=\"0 0 23 22\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">
                     <desc>
                             Created with Pixso.
                     </desc>
                     <defs/>
                     <path id=\"path\" d=\"M15.52 0C19.39 0 22 3.91 22 7.56C22 14.94 11.19 21 11 21C10.8 21 0 14.94 0 7.56C0 3.91 2.6 0 6.47 0C8.7 0 10.15 1.19 11 2.24C11.84 1.19 13.29 0 15.52 0Z\" fill=\"#000000\" fill-opacity=\"0\" fill-rule=\"nonzero\"/>
                     <path id=\"path\" d=\"M22 7.56C22 14.94 11.19 21 11 21C10.8 21 0 14.94 0 7.56C0 3.91 2.6 0 6.47 0C8.7 0 10.15 1.19 11 2.24C11.84 1.19 13.29 0 15.52 0C19.39 0 22 3.91 22 7.56Z\" stroke=\"#FFFFFF\" stroke-opacity=\"1.000000\" stroke-width=\"0.704000\" stroke-linejoin=\"round\"/>
                 </svg>


                         </div>
                 </a>
             </div>

             <div class=\"item\">
                 <a href=\"profile.php\">
                 <div class=\"icon\">
                 <svg width=\"25.000000\" height=\"27.000000\" viewBox=\"0 0 25 27\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">
                     <desc>
                             Created with Pixso.
                     </desc>
                     <defs>
                         <clipPath id=\"clip2_41\">
                             <rect id=\"Layer_1\" width=\"24.923077\" height=\"27.000000\" fill=\"white\" fill-opacity=\"0\"/>
                         </clipPath>
                     </defs>
                     <g clip-path=\"url(#clip2_41)\">
                         <ellipse id=\"circle\" cx=\"12.521088\" cy=\"7.961914\" rx=\"5.978838\" ry=\"6.292745\" fill=\"#000000\" fill-opacity=\"0\"/>
                         <ellipse id=\"circle\" cx=\"12.521088\" cy=\"7.961914\" rx=\"5.978838\" ry=\"6.292745\" stroke=\"#FFFFFF\" stroke-opacity=\"1.000000\" stroke-width=\"0.704000\"/>
                         <path id=\"path\" d=\"\" fill=\"#000000\" fill-opacity=\"0\" fill-rule=\"nonzero\"/>
                         <path id=\"path\" d=\"M1.56 25.78L1.95 23.53C2.17 22.23 2.61 21.01 3.24 19.87C3.87 18.73 4.67 17.73 5.64 16.89C6.61 16.04 7.68 15.4 8.86 14.95C10.04 14.5 11.26 14.27 12.52 14.27C13.77 14.27 14.99 14.5 16.18 14.95C17.36 15.4 18.43 16.05 19.4 16.9C20.36 17.75 21.16 18.74 21.8 19.88C22.43 21.03 22.86 22.25 23.09 23.55L23.47 25.8\" stroke=\"#FFFFFF\" stroke-opacity=\"1.000000\" stroke-width=\"0.704000\"/>
                     </g>
                 </svg>

                         </div>
                 </a>
             </div>

             <div class=\"item\">
                 <a href=\"cart.php\">
                 <div class=\"icon\">
                 <svg width=\"26.000000\" height=\"26.000000\" viewBox=\"0 0 26 26\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">
                     <desc>
                             Created with Pixso.
                     </desc>
                     <defs/>
                     <ellipse id=\"circle\" cx=\"7.886810\" cy=\"22.750000\" rx=\"1.577354\" ry=\"1.625000\" fill=\"#FFFFFF\" fill-opacity=\"1.000000\"/>
                     <ellipse id=\"circle\" cx=\"18.928192\" cy=\"22.750000\" rx=\"1.577354\" ry=\"1.625000\" fill=\"#FFFFFF\" fill-opacity=\"1.000000\"/>
                     <path id=\"path\" d=\"M22.08 5.68L4.59 5.68L3.94 2.27C3.85 1.83 3.59 1.61 3.15 1.62L0 1.62L0 3.25L2.5 3.25L5.52 18.84C5.6 19.29 5.87 19.5 6.3 19.5L20.5 19.5L20.5 17.87L6.95 17.87L6.3 14.62L20.5 14.62C20.93 14.63 21.19 14.42 21.29 13.99L22.87 6.67C22.92 6.42 22.87 6.18 22.71 5.98C22.54 5.78 22.33 5.68 22.08 5.68ZM19.87 13L6 13L4.9 7.31L21.09 7.31L19.87 13Z\" fill=\"#FFFFFF\" fill-opacity=\"1.000000\" fill-rule=\"nonzero\"/>
                     <rect id=\"_Transparent_Rectangle_\" width=\"25.237669\" height=\"26.000000\" fill=\"#000000\" fill-opacity=\"0\"/>
                 </svg>

                         </div>
                 </a>
             </div>
         </div>
      </div>
    </div>";
      
    }

    public function non_index_bar(){
        include_once('MVC/header.php');
    }
    
    public function gameinfo(){
        if(empty($_GET)){
            header('Location: index.php');
        }else{
            //  работа с папками и файлами 

            // 
            $id=htmlspecialchars($_GET['id']);
            $query=mysqli_query($this->conn,"SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ge.id,ge.gender,mo.id,mo.item_id,mo.gamemod,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN mode mo ON mo.id=i.mode JOIN photos ph ON ph.item_id=i.id WHERE i.id=$id");
             $row=mysqli_fetch_assoc($query);
             $price = $row['sale'];
             $price_old = $row['cost'];
             $percent = round((($price - $price_old) * 100) / $price); 

             $wishslit_q=mysqli_query($this->conn,"SELECT  user_wishlist.user_id,user_wishlist.item_id FROM user_wishlist WHERE user_wishlist.item_id=$row[item_id];");
            
             $card_q=mysqli_query($this->conn,"SELECT user_card.card_item FROM user_card WHERE user_card.card_item=$row[item_id];");
               
             $dir="images/items";
           
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
            $wallpaper_file = $info[1];
            $wallpaper_path="$dir/$row[images_folder]/desc/$wallpaper_file";
            $screenshot_array = $info[2];
            
            $screenshot_path="$dir/$row[images_folder]/desc/screenshots";
             if(!isset($cover)){
                echo "  <div class=\"img\"> <img src=\"images/items/empy_cover.png\" width=\"200px\" alt=\"\">
                <div class=\"year\">
                    <h5>Год выпуска: $row[year]</h5>
                </div>";
             }else{
                echo "  <div class=\"img\"> <img src=\"$cover\" width=\"200px\" alt=\"\">
                <div class=\"year\">
                    <h5>Год выпуска: $row[year]</h5>
                </div>";
             }
       
        echo" 
        <div class=\"Bye_block\"> 
        <div class=\"cost\"><h5> $row[cost] ₽</h5></div><div class=\"sale\">$percent%</div>
        <form action=\"\" method=\"POST\">
         ";
         if(empty($_SESSION['status'])){
            if(mysqli_num_rows($card_q)>0){
                echo"  <button type=\"button\"class=\"btn btn-success\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Игра в вашей корзине\">В корзине</button>";
        }else{
            echo" <button type=\"submit\" name=\"new_card_item\" value=\"$row[item_id]\" class=\"btn btn-primary\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Добавить эту игру в вашу корзину\">В корзину</button>";
        }
        if(mysqli_num_rows($wishslit_q)>0){
            echo"  <button type=\"button\"class=\"btn\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Игра в вашем списке желаемого\"><i>";?>
            <svg width="44px" height="44px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M2 9.1371C2 14 6.01943 16.5914 8.96173 18.9109C10 19.7294 11 20.5 12 20.5C13 20.5 14 19.7294 15.0383 18.9109C17.9806 16.5914 22 14 22 9.1371C22 4.27416 16.4998 0.825464 12 5.50063C7.50016 0.825464 2 4.27416 2 9.1371Z" fill="#ff0000"></path> </g></svg>             
            <?php echo "</i></button>";

        }else{
            echo"<button type=\"submit\" name=\"new_wishlist_item\" value=\"$row[item_id]\" class=\"btn\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Добавить эту игру в ваш список желаемого\">";?>
                   
                <svg width="44px" height="44px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" clip-rule="evenodd" d="M12 6.00019C10.2006 3.90317 7.19377 3.2551 4.93923 5.17534C2.68468 7.09558 2.36727 10.3061 4.13778 12.5772C5.60984 14.4654 10.0648 18.4479 11.5249 19.7369C11.6882 19.8811 11.7699 19.9532 11.8652 19.9815C11.9483 20.0062 12.0393 20.0062 12.1225 19.9815C12.2178 19.9532 12.2994 19.8811 12.4628 19.7369C13.9229 18.4479 18.3778 14.4654 19.8499 12.5772C21.6204 10.3061 21.3417 7.07538 19.0484 5.17534C16.7551 3.2753 13.7994 3.90317 12 6.00019Z" stroke="#61ffad" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
            <?php echo "</button>";
        }
         }else{
            echo"";
         }
    
        echo" </form>
        </div>
         </div>
        <div class=\"text_info\">
            <div class=\"title\">
                <h3>$row[name]</h3>
            </div>
            <div class=\"desciption\">";
            if(empty($row['description'])){
                echo " <b><h4>Описание отсутствует</h4></b>";
            }else{
                echo "<b><p>$row[description] </p></b>";
            }
            echo"</div>
            <div class='screenshot_courosel'>
                    <h4> Скриншоты:</h4>
                    <div class=\"owl-carousel\">";
                    foreach ($screenshot_array as $key => $value) {
                        echo "<div class=\"item\"> 
                   <img src=\"$dir/$row[images_folder]/descr/screenshots/$value\" class=\"d-block\" style=\"width: 300px;\" alt=\"...\">
                    </div>";
                          }
                          
                    echo "
                    
              </div>
            </div>
             <div class=\"tags\">
             
                <div class=tag_item><p>$row[gender]</p></div><div class=tag_item><p>$row[gamemod]</p></div>
            </div>
            <div class=\"search\">

            </div>
        </div>";
        }
    }
    public function Promo_slider(){
        $query=mysqli_query($this->conn,"SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id  ORDER BY RAND() LIMIT 1;");
         while ($row=mysqli_fetch_assoc($query)) {
            $dir="images/items";
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
     
            $info= $this->Catalog_sorting($row['images_folder']);
            $wallpaper_file = $info[1];
           $wallpaper_path=$dir."/".$row['images_folder']."/descr/".$wallpaper_file;
              echo  "
             <div class=\"Promo_item\">
             <a href=\"game.php?id=$row[id]\"><img src=\"$wallpaper_path\" class=\"d-block\"   alt=\"...\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Кликните для перехода на страницу товара\">
                <div class=\"Promo_text\">
                <h5>$row[name]</h5> 
                <div class=\"cost\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Цена на товар\"><h5> $row[cost] ₽</h5></div>
                <div class=\"sale\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Процент экономии при покупке у нас\">$percent%</div>
                </div>
                </a>
             </div>
             ";
         }  
    }
    public function popular_games(){
        $query=mysqli_query($this->conn,"SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id ORDER BY RAND() LIMIT 6");
         while ($row=mysqli_fetch_assoc($query)) {
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
            $dir="images/items";
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
             echo  "
             <div class=\"item\">
             <a href=\"game.php?id=$row[id]\"><img src=\"$cover\" class=\"d-block\" style=\"width: 200px;\" alt=\"...\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Кликните для перехода на страницу товара\">
                 <h5>$row[name]</h5></a>
                 <div class=\"cost\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Цена на товар\"><h5> $row[cost] ₽</h5></div>
                 <div class=\"sale\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Процент экономии при покупке у нас\">$percent%</div>
             </div>
             ";
         }  
    }

    public function new_games(){
        $query=mysqli_query($this->conn,"SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id  ORDER BY i.id DESC ");
         while ($row=mysqli_fetch_assoc($query)) {
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
            $dir="images/items";
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
             echo  "
             <div class=\"item\">
             <a href=\"game.php?id=$row[id]\"><img src=\"$cover\" class=\"d-block\" style=\"width: 200px;\" alt=\"...\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Кликните для перехода на страницу товара\">
                 <h5>$row[name]</h5></a>
                 <div class=\"cost\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Цена на товар\"><h5> $row[cost] ₽</h5></div>
                 <div class=\"sale\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Процент экономии при покупке у нас\">$percent%</div>
             </div>
             ";
         }  
    }



    public function game_sales(){
        $query=mysqli_query($this->conn,"SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id  ORDER BY i.cost DESC ");
        
         while ($row=mysqli_fetch_assoc($query)) {
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
            $dir="images/items";
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
             echo  "
             <div class=\"item\">
             <a href=\"game.php?id=$row[id]\"><img src=\"$cover\" class=\"d-block\" style=\"width: 200px;\" alt=\"...\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Кликните для перехода на страницу товара\">
                 <h5>$row[name]</h5></a>
                 <div class=\"cost\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Цена на товар\"><h5> $row[cost] ₽</h5></div>
                 <div class=\"sale\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Процент экономии при покупке у нас\">$percent%</div>
             </div>
             ";
         }  
    }
    
    public function search_results($search_text=null,$gender=null,$mode=null){ 
        if(!empty($search_text)){
   
            $query=mysqli_query($this->conn," SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id  WHERE i.name LIKE '%$search_text%' ;");
        }
        if(!empty($gender) && !empty($mode)){
            $query=mysqli_query($this->conn," SELECT i.id,i.name,i.year,i.description,i.gender,i.mode,i.cost,i.sale,ph.item_id,ph.images_folder FROM item i JOIN gender ge ON ge.id = i.gender JOIN photos ph ON ph.item_id=i.id   WHERE i.gender=$gender AND i.mode=$mode;");
        }
         if(mysqli_num_rows($query)>0){
            
            while ($row=mysqli_fetch_assoc($query)) {
                $price = $row['sale'];
                $price_old = $row['cost'];
                $percent = round((($price - $price_old) * 100) / $price); 
                
                $dir="images/items";
                $info= $this->Catalog_sorting($row['images_folder']);
                 $cover_name = $info[0];
                 $cover= $dir."/".$row['images_folder']."/".$cover_name;

                echo  "
                <div class=\"item\">
                <a href=\"game.php?id=$row[id]\"><img src=\"$cover\" class=\"d-block\" style=\"width: 200px;\" alt=\"...\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Кликните для перехода на страницу товара\">
                    <h5>$row[name]</h5></a>
                    <div class=\"cost\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Цена на товар\"><h5> $row[cost] ₽</h5></div><div class=\"sale\"  data-toggle=\"tooltip\" data-placement=\"top\" title=\"Процент экономии при покупке у нас\">$percent%</div>
                </div>
                ";
            }  
        }else{
            echo "<b><h4 style=' text-align: center; margin:100px'>Результатов нет....</h4></b>";
        }
       
     



    }
        public  function Catalog_sorting($folder_name){

        $dir="images/items/";
       
           $directory=$dir.$folder_name."/";
           
           $files = array();
           $directories = array();
           
           // Получаем список файлов и директорий из папки
           $items = scandir($directory);
           
           foreach ($items as $item ) {
               // Пропускаем текущий и родительский каталоги
               if ($item === '.' || $item === '..') {
                   continue;
               }
               
               // Проверяем, является ли элемент файлом
               if (is_file($directory . '/' . $item)) {
                   $files[] = $item;
               } elseif (is_dir($directory . '/' . $item)) {
                   $directories[] = $item;
               }
           }
           
           // Выводим список файлов
        
           foreach ($files as $cover_file) {
                $cover_file . "<br>";
           }
           
           // Выводим список директорий
            foreach ($directories as $next) {
                $next . "<br>";
           }
       
           $directory=$dir.$folder_name."/".$next."/";
           
           $files = array();
           $directories = array();
           
           // Получаем список файлов и директорий из папки
           $items = scandir($directory);
           
           foreach ($items as $item ) {
               // Пропускаем текущий и родительский каталоги
               if ($item === '.' || $item === '..') {
                   continue;
               }
               
               // Проверяем, является ли элемент файлом
               if (is_file($directory . '/' . $item)) {
                   $files[] = $item;
               } elseif (is_dir($directory . '/' . $item)) {
                   $directories[] = $item;
               }
           }
           
           // Выводим список файлов
            foreach ($files as $promo_img) {
                 $promo_img . "<br>";
           }
           
           // Выводим список директорий
            foreach ($directories as $dir) {
                 $dir . "<br>";
              
           }
       
           $screenshot_array= scandir($directory."/".$dir);
           $slised_screenshot_array=array_slice($screenshot_array,2);
           
           return array($cover_file,$promo_img,$slised_screenshot_array); 
       
      }

    // Функционал админки
    // Создание товара 


    public function create_item($item_name=null,$item_description=null,$item_year=null,$item_cover=null,$site_cost=null,$off_cost=null,$item_gender=null,$item_type=null,$item_promo_img=null,$item_screenshots=null){
        
        $folder_replace=str_replace(" ","_",$item_name.'_images');
        $folder=$folder_replace;
        
       $query= mysqli_query($this->conn,"INSERT INTO `item`( `name`, `description`, `year`,`cost`, `sale`, `gender`, `mode`) VALUES ('$item_name','$item_description','$item_year','$site_cost','$off_cost','$item_gender','$item_type')");
       $last_id= mysqli_insert_id($this->conn);
        mysqli_query($this->conn,"INSERT INTO `photos`( `item_id`, `images_folder`) VALUES ('$last_id','$folder')");
      $structure = 'images/items/'.$item_name.'_images/descr/screenshots/';
       $cover_path='images/items/'.$item_name.'_images/';
       $banner_path='images/items/'.$item_name.'_images/descr/';
       $screenshots_path='images/items/'.$item_name.'_images/descr/screenshots/';
    //   Перенос скриншотов
        if (!mkdir($structure, 0777, true)) {
            die('Не удалось создать директории...');
        }else{

                    //Перенос Обложки
                $tmp_name=$_FILES['item_cover']['tmp_name'];
         
                move_uploaded_file($tmp_name,$_SERVER['DOCUMENT_ROOT']."/DIPLOM/".$cover_path.$_FILES['item_cover']['full_path']);
                
                // 
                //Перенос Баннера
                $tmp_name=$_FILES['item_promo_img']['tmp_name'];
                echo $tmp_name;
        
                move_uploaded_file($tmp_name,$_SERVER['DOCUMENT_ROOT']."/DIPLOM/".$banner_path.$_FILES['item_promo_img']['full_path']);
                
                // 
            $anime_array=$item_screenshots;
 
            for ($i=0; $i <count($anime_array['name']) ; $i++) { 
            
            $tmp_name=$anime_array['tmp_name'][$i];
            
            $uploads_dir = '/images/items/'.$item_name.'_images/descr/screenshots/';

            move_uploaded_file($tmp_name,$_SERVER['DOCUMENT_ROOT']."/DIPLOM/$uploads_dir".$anime_array['full_path'][$i]);
            
            header("Location:admin_page.php");
            }

       }


 
        
    }
    public function statistic(){
        $query= mysqli_query($this->conn,"SELECT * FROM `item` ORDER BY id DESC LIMIT 1");
        while ($row=mysqli_fetch_assoc($query)) {
          echo "<h2> Последняя добавленная игра : <a style='color:pink;' href='game.php?id=$row[id]'>$row[name]</a></h2>";
        }
       
    }

// Функции входа и регистрации
    public function user_log($username,$password){
 
        if(!empty($username)&& !empty($password)){
          $pass=md5($password);
          
          $res=mysqli_query($this->conn,"SELECT * FROM users WHERE login='$username' AND passworld='$pass' ");
          $row=mysqli_fetch_assoc($res);
          if(mysqli_num_rows($res)>0){
            $_SESSION["id"]=$row['id'];
            $_SESSION["email"]=$username;
            $_SESSION["password"]=$password;
            header('Location: index.php');
          }else{
            echo "Нет такой пары пароль-логин";
          }

        }
   }
  
 
   public function user_reg($username,$password){
        if(!empty($username)&& !empty($password)){
            $pass=md5($password);
            $res=mysqli_query($this->conn,"SELECT * FROM users WHERE login='$username' AND passworld='$pass' ");
            // $table_name= $username."_wishlist";
            // $res=mysqli_query($this->conn,"CREATE TABLE `$table_name` (
            //     `id` int(3) NOT NULL AUTO_INCREMENT,
            //     `item_id` int(3) NOT NULL
            //   ) ENGINE=InnoDB DEFAULT CHARSET=utf8; ");

        // $table_name2= $username."_cardlist";
        //     $res=mysqli_query($this->conn,"CREATE TABLE `$table_name2` (
        //         `id` int(3) NOT NULL AUTO_INCREMENT,
        //         `item_id` int(3) NOT NULL
        //       ) ENGINE=InnoDB DEFAULT CHARSET=utf8; ");
            if(mysqli_num_rows($res)>0){
                header("location:index.php");
            echo "Такой пользователь уже есть";
            }else{
                
                $res=mysqli_query($this->conn,"INSERT INTO `users`( `login`, `passworld`) VALUES ('$username','$pass')");
                header("location:index.php");
                echo "Регистрация успешна";
            }
        
        
        }
    }

    // Страница профиля
    public function print_user_info(){
        $res=mysqli_query($this->conn,"SELECT * FROM users WHERE login='$_SESSION[email]' ");
        $row=mysqli_fetch_assoc($res);
 
        echo "<section class=\"vh-100\" style=\"background-color: black;\">
        <div class=\"container py-5 h-100\">
          <div class=\"row d-flex justify-content-center align-items-center h-100\">
            <div class=\"col col-lg-6 mb-4 mb-lg-0\">
              <div class=\"card mb-3\" style=\"border-radius: .5rem;\">
                <div class=\"row g-0\">
                  <div class=\"col-md-4 gradient-custom text-center text-white\"
                    style=\"border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;\">
                    <img src=\"images/0dc3a8d81408183ccec3a0b9b986a24d.jpg\"
                      alt=\"Avatar\" class=\"img-fluid my-5\" style=\"width: 80px; border-radius:2px;\" />
                    <h5>$row[login]</h5>
                    <i class=\"far fa-edit mb-5\"></i>
                  </div>
                  <div class=\"col-md-8\">
                    <div class=\"card-body p-4\">
                      <h6>Профиль</h6>
                      <hr class=\"mt-0 mb-4\">
                      <div class=\"row pt-1\">
                   
                        <div class=\"col-6 mb-3\">
                          <h6>Список желаемого</h6>
                          <p class=\"text-white\"><a href=\"wishlist.php\">Список</a></p>
                        </div>
                        <div class=\"col-6 mb-3\">
                          <h6>Корзина</h6>
                          <p class=\"text-white\"><a href=\"card.php\">Корзина</a></p>
                        </div>
                        <div class=\"col-6 mb-3\">
                          <h6>Дата регистрации</h6>
                          <p class=\"text-white\">$row[reg_date]</p>
                        </div>
                      </div>
                   
                    
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section> ";

    }

    // Добавление нового товара в списки
    public function add_to_wishlist($user_id,$wishlist_item_id){
        if(!empty($user_id) && !empty($wishlist_item_id)){
            $res=mysqli_query($this->conn,"INSERT INTO `user_wishlist`( `user_id`, `item_id`) VALUES ('$user_id','$wishlist_item_id');");
            
 
        }
    }

    public function print_user_wishlist($user_id){
        $query=mysqli_query($this->conn,"SELECT item.id,item.name,item.year,item.cost,item.sale,user_wishlist.item_id,ph.images_folder FROM item JOIN photos ph ON ph.item_id=item.id INNER JOIN user_wishlist ON user_wishlist.item_id=item.id WHERE user_wishlist.user_id=$user_id;");
        
        while ($row=mysqli_fetch_assoc($query)) {
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
            
            $dir="images/items";
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
 
                echo "<tr>
                  <th scope=\"row\">
                <div class=\"d-flex align-items-center\">
                  <img src=\"$cover\" class=\"img-fluid rounded-3\"
                    style=\"width: 120px;\" alt=\"товар\">
                  <div class=\"flex-column ms-4\">
                    <p class=\"mb-2\">$row[name]</p>
                    <p class=\"mb-0\">$row[year]</p>
                  </div>
                </div>
              </th>
              <td class=\"align-middle\">
              <p class=\"mb-0\" style=\"font-weight: 500;\">$row[cost]</p>
            </td>
              <td class=\"align-middle\">
              <p class=\"mb-0\" style=\"font-weight: 500; color:orange;\">-$percent%</p>
            </td>
          </tr>";
        }
    }
    public function add_to_card($user_id,$card_item_id){
        if(!empty($user_id) && !empty($card_item_id)){
            $res=mysqli_query($this->conn,"INSERT INTO `user_card`( `user_id`, `card_item`) VALUES ('$user_id','$card_item_id')");
             
 
        }
    }
    public function print_user_card($user_id){
        $query=mysqli_query($this->conn,"SELECT item.id,item.name,item.year,item.cost,item.sale,user_card.card_item,ph.images_folder FROM item JOIN photos ph ON ph.item_id=item.id INNER JOIN user_card ON user_card.card_item=item.id WHERE user_card.user_id=$user_id;");
        
        while ($row=mysqli_fetch_assoc($query)) {
            $price = $row['sale'];
            $price_old = $row['cost'];
            $percent = round((($price - $price_old) * 100) / $price); 
            
            $dir="images/items";
            $info= $this->Catalog_sorting($row['images_folder']);
             $cover_name = $info[0];
             $cover= $dir."/".$row['images_folder']."/".$cover_name;
 
                echo "<tr>
                  <th scope=\"row\">
                <div class=\"d-flex align-items-center\">
                  <img src=\"$cover\" class=\"img-fluid rounded-3\"
                    style=\"width: 120px;\" alt=\"товар\">
                  <div class=\"flex-column ms-4\">
                    <p class=\"mb-2\">$row[name]</p>
                    <p class=\"mb-0\">$row[year]</p>
                  </div>
                </div>
              </th>
              <td class=\"align-middle\">
              <p class=\"mb-0\" style=\"font-weight: 500;\">$row[cost]</p>
            </td>
              <td class=\"align-middle\">
              <p class=\"mb-0\" style=\"font-weight: 500; color:orange;\">-$percent%</p>
            </td>
          </tr>";
        }
    }





 
}
 

 
 