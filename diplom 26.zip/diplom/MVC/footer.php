<br>
<br>
<br>
<br>
<br>
<div class="footer_wrap">
        <div class="container">
            <!-- Footer -->
<footer class="bg-dark text-center text-white">
  <!-- Grid container -->
  <div class="container p-4">



    <!-- Section: Text -->
    <section class="mb-4">
      <p>
        Сайт по продаже 
      </p>
    </section>
    <!-- Section: Text -->


    <!-- Section: Links -->
    <section class="">
      <!--Grid row-->
      <div class="row">
       
       
     

      
      </div>
      <!--Grid row-->
    </section>
    <!-- Section: Links -->

  </div>
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2024 Copyright:
    <a class="text-white" href="#">Выполнил Арслан Дадажиев</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
        </div>
    </div>
