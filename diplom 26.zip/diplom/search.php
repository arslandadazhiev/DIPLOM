<?php 
session_start();
 include('webclass.php');
$sc= new SiteClass;
if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <script src="assets/js/color-modes.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
     <!-- owl -->
     <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.css">
    <!--  -->
 <style>

    body{
        width: 1200px;
        height: fit-content;
    }
    .site_wrap{
        width: 1200px;
        height: fit-content;
    }
    
 </style>
</head>
<body>
 <div class="site_wrap">
 <?php 
    if(!empty($_SESSION['status'])){
        require_once("MVC/header_admin.php");

    }else{
        require_once("MVC/header.php");

    }
      ?>
     <div class="search_wrap">
        <div class="filters">
         
   
        <?php 
        if(empty($_GET['gender'])){
            $_GET['gender']=null;
        }
        if(empty($_GET['mode'])){
            $_GET['mode']=null;
        }
        $g1=$_GET['gender'];
        switch ($g1) {
            case '1':
                $g1s="checked";
                $g2s="";
                $g3s="";
                $g4s="";
                $g5s="";
                break;
            case '2':
                $g1s="";
                $g2s="checked";
                $g3s="";
                $g4s="";
                $g5s="";
                break;
            case '3':
                $g1s="";
                $g2s="";
                $g3s="checked";
                $g4s="";
                $g5s="";
                break;
            case '4':
                $g1s="";
                $g2s="";
                $g3s="";
                $g4s="checked";
                $g5s="";
                break;
            case '5':
                $g1s="";
                $g2s="";
                $g3s="";
                $g4s="";
                $g5s="checked";
                break;
            
            default:
            $g1s="";
            $g2s="";
            $g3s="";
            $g4s="";
            $g5s="";
            break;
        }
        $m1=$_GET['mode'];
        switch ($g1) {
            case '1':
                $m1s="checked";
                $m2s="";
                $m3s="";
                break;
            case '2':
                $m1s="";
                $m2s="checked";
                $m3s="";
                break;
            case '3':
                $m1s="";
                $m2s="";
                $m3s="checked";
                break;        
            default:
            $m1s="";
            $m2s="";
            $m3s="";
        
            break;
        }
        
        
        ?>
        <form action="" method="get"> 
            <h4>Жанры</h4>
            <div class="form-check form-switch ">
            <input class="form-check-input" type="radio" name="gender" value="1" <?=$g1s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Экшен
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio"  name="gender" value="2" <?=$g2s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Приключения
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio" name="gender" value="3"  <?=$g3s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Ролевые
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio" name="gender" value="4" <?=$g4s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Стратегии
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio" name="gender" value="5" <?=$g5s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Гонки
            </label>
            </div>

            <h4>Тип игры</h4>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio" name="mode" value="1" <?=$m1s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Одиночная игра
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio"  name="mode" value="2" <?=$m1s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Локальный коорператив
            </label>
            </div>
            <div class="form-check form-switch">
            <input class="form-check-input" type="radio" name="mode" value="3" <?=$m1s?> id="flexCheckDefault" required>
            <label class="form-check-label" for="flexCheckDefault">
            Онлайн
            </label>
            </div>
             
            <button type="submit" id="filter_btn" class="btn btn-outline-warning">Применить</button>
            </form>




        </div>
        <div class="results">
            <h3> Результат поиска:</h3>
        <div class="row row-cols-1 row-cols-md-2 g-4">
                               
                               <?php if(isset($_POST['search']) ){
                                    $search_text= htmlspecialchars($_POST['search']);
                                        $sc->search_results($search_text);
                                    
                                    }?>    
                               <?php if(isset($_GET['gender']) && isset($_GET['mode']) ){
                                   $search_text="";
                                    $gender=htmlentities($_GET['gender']);
                                    $mode=htmlentities($_GET['mode']);
                                        $sc->search_results($search_text,$gender,$mode);
                                    
                                    }?>    
                                                      
                                                  </div>
        </div>
                                       
     </div>

    
     <div class="sales_games border-bottom">
        <h1>Скидки</h1>
            <div class="owl-carousel">
                <?php $sc->game_sales(); ?>
          </div>
    </div>  





    <?php require_once("MVC/footer.php"); ?>

    
    </div>
    


 </div>
 <script src="js/jquery-3.7.1.js"></script>
<script src="jquery.min.js"></script>
<script src="owlcarousel/owl.carousel.min.js"></script>

 <script>
  $('.owl-carousel').owlCarousel({
    items:4,
    loop:true,
    margin:100,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
 </script>
</body>
</html>