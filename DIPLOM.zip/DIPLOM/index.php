<?php 
session_start();
 
include('webclass.php');
$sc= new SiteClass;
if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <script src="assets/js/color-modes.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
     <!-- owl -->
     <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.css">
    <!--  -->
 
</head>
<body>
<script>
  $('.Promo-owl-carousel').owlCarousel({
    items:1,
    loop:true,
    margin:100,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
 </script>
    <?php 
    if(!empty($_SESSION['status'])){
        require_once("MVC/header_admin.php");

    }else{
        require_once("MVC/header.php");

    }
      ?>

 <div class="site_wrap">
    
        
 
                 <div class="container"> 
                    <div class="content  ">
                    <div class="nav-left">
                        <div class="nav-left-item">
                            <div class="btn-group dropend">
                            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                Игры для PC
                            </button>
                            <ul class="dropdown-menu">
                                      <li><a href="search.php?gender=1">Экшены</a></li> 
                                    <li><a href="search.php?gender=2">Приключения</a></li> 
                                    <li><a href="search.php?gender=3">Ролевые</a></li> 
                                    <li><a href="search.php?gender=4">Стратегии</a></li> 
                                    <li><a href="search.php?gender=5">Гонки</a></li> 
                            </ul>
                            </div>

                        </div>
                        <div class="nav-left-item">
                            <div class="btn-group dropend ">
                            <button type="button" class="btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                Playstation
                            </button>
                            <ul class="dropdown-menu">
                            <li><a href="search.php?gender=1">Экшены</a></li> 
                                    <li><a href="search.php?gender=2">Приключения</a></li> 
                                    <li><a href="search.php?gender=3">Ролевые</a></li> 
                                    <li><a href="search.php?gender=4">Стратегии</a></li> 
                                    <li><a href="search.php?gender=5">Гонки</a></li> 
                            </ul>
                            </div>

                        </div>
                        <div class="nav-left-item">
                            <div class="btn-group dropend">
                            <button type="button" class="btn   dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                Xbox
                            </button>
                            <ul class="dropdown-menu">
                            <li><a href="search.php?gender=1">Экшены</a></li> 
                                    <li><a href="search.php?gender=2">Приключения</a></li> 
                                    <li><a href="search.php?gender=3">Ролевые</a></li> 
                                    <li><a href="search.php?gender=4">Стратегии</a></li> 
                                    <li><a href="search.php?gender=5">Гонки</a></li> 
                                  
                            </ul>
                            </div>

                        </div>
                        <div class="nav-left-item">
                            <div class="btn-group dropend">
                            <button type="button" class="btn  dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                Nintendo Switch
                            </button>
                            <ul class="dropdown-menu">
                            <li><a href="search.php?gender=1">Экшены</a></li> 
                                    <li><a href="search.php?gender=2">Приключения</a></li> 
                                    <li><a href="search.php?gender=3">Ролевые</a></li> 
                                    <li><a href="search.php?gender=4">Стратегии</a></li> 
                                    <li><a href="search.php?gender=5">Гонки</a></li> 
                            </ul>
                            </div>

                        </div>
                    </div>
                            <div class="new_item_wrap">
                                            <div class="container">
                                                <div class="slider">
                                                <div class="Promo-owl-carousel">
                                                    <?php $sc->Promo_slider(); ?>
                                            
                                                </div>
                                            </div>
                                </div>
                    </div>
                   
                </div>
        
       
     
   
 
    <div class="slider_sale_releas_top_wrap  ">
      
        <div class="sales_games border-bottom">
        <h1>Скидки</h1>
            <div class="owl-carousel">
            <?php $sc->game_sales(); ?>
          </div>
        </div>
  
        <ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"> <h2>Новые игры</h2></button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false"> <h2>Популярные игры</h2></button>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
    <div class="new_games border-bottom">
            <!-- <h1>Новые игры</h1> -->
                <div class="owl-carousel">
                <?php $sc->new_games(); ?>
        
            </div>
            </div>
  </div>
   <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
   <div class="popular_games border-bottom">
            <!-- <h1>Популярные игры</h1> -->
            <div class="owl-carousel">
             <?php $sc-> popular_games(); ?>
    
          </div>
          <a href="catalog">все игры</a>
        </div>
   </div>
</div>
    </div>
    <div class="container">
        <div class="coming_soon_wrap">
            
                    
                    <!-- <div class="coming_soon_block">
                        <h1>Скоро выйдут:</h1>
                            <div class="row row-cols-1 row-cols-md-2 g-4">
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                                <div class="soon_block_item">
                                    <a href=""><img src="images/games/stalker.jpg" class="d-block" style="width: 200px;" alt="...">
                                    
                                    <h5>Stalker 2 </a></h5>
                                    <div class="pre_order"><h5>$59.99</h5></div>
                                </div>
                            
                            
                        </div>
                   </div> -->
                            <h1>Скоро выйдут:</h1>
                   <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button  type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                        <img src="images/games/preorder/silenthill2.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>Silent Hill 2 </h2>
                            <p>Главный герой Джеймс Сандерленд получает письмо от своей погибшей жены Мэри, которая просит его приехать в город Сайлент Хилл. Джеймс решает отправиться в это место, чтобы найти покой и утешение.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="images/games/preorder/vtmb2.jpeg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>Vampire: The Masquerade - Bloodlines 2</h2>
                            <p>Древний вампир приходит в себя в современном Сиэтле — но город стоит на грани войны. Кому достанется власть? Каким станет город? Решать вам — знакомьтесь с претендентами и выбирайте сторону...</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="images/games/preorder/stalker-2.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h2>S.T.A.L.K.E.R. 2: Сердце Чернобыля</h2>
                            <p>Действие игры происходит в постапокалиптической зоне отчуждения Чернобыльской АЭС, где в 2006 году....</p>
                        </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                    </div>
        </div>
                
    </div>
    </div>

   
    <!-- подвал сайта -->
   <?php require_once("MVC/footer.php"); ?>
 </div>
 <script src="js/jquery-3.7.1.js"></script>
<script src="jquery.min.js"></script>
<script src="owlcarousel/owl.carousel.min.js"></script>

 <script>
  $('.owl-carousel').owlCarousel({
    items:4,
    loop:true,
    margin:100,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
 </script>
</body>
</html>