<?php
 
 
?>
<div class="top-menu-wrap">
                <div class="top-menu-items">
                    <div class="left">
                       <a href="index.php">
                       <div class="item"> 
                            <svg width="305.000000" height="62.000000" viewBox="0 0 305 62" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <desc>
                                    Created with Pixso.
                            </desc>
                            <defs>
                                <clipPath id="clip6_3">
                                    <rect id="memory-gamepad-down-left" width="37.846153" height="41.000000" transform="translate(-0.230713 0.000000)" fill="white" fill-opacity="0"/>
                                </clipPath>
                            </defs>
                            <path id="GSHOP" d="M67.95 17.17L63.11 17.17C62.27 14.4 60.12 12.71 56.97 12.71C52.73 12.71 49.68 15.98 49.68 21.88C49.68 27.81 52.69 31.09 57.07 31.09C61 31.09 63.5 28.73 63.58 25L57.54 25L57.54 21.29L68.17 21.29L68.17 24.44C68.17 31.19 63.53 35.36 57.05 35.36C49.82 35.36 44.91 30.21 44.91 21.93C44.91 13.49 50.05 8.45 56.91 8.45C62.69 8.45 67.15 12.04 67.95 17.17ZM91.55 16.01L86.99 16.01C86.74 13.79 84.88 12.47 82.05 12.47C79.09 12.47 77.32 13.91 77.31 15.88C77.28 18.07 79.6 18.97 81.76 19.49L84.21 20.1C88.15 21.04 91.89 23.1 91.91 27.65C91.89 32.26 88.25 35.39 81.98 35.39C75.88 35.39 72 32.46 71.81 27.26L76.48 27.26C76.67 30.01 78.97 31.34 81.93 31.34C85.03 31.34 87.15 29.84 87.16 27.6C87.15 25.57 85.28 24.69 82.46 23.97L79.48 23.21C75.18 22.09 72.5 19.94 72.5 16.18C72.49 11.55 76.62 8.45 82.12 8.45C87.69 8.45 91.46 11.59 91.55 16.01ZM134.27 8.45C141.14 8.45 146.31 13.44 146.31 21.91C146.31 30.36 141.14 35.36 134.27 35.36C127.39 35.36 122.24 30.35 122.24 21.91C122.24 13.44 127.39 8.45 134.27 8.45ZM100.87 35L96.13 35L96.13 8.81L100.87 8.81L100.87 19.9L113 19.9L113 8.81L117.76 8.81L117.76 35L113 35L113 23.88L100.87 23.88L100.87 35ZM155.54 35L150.81 35L150.81 8.81L160.62 8.81C166.64 8.81 169.85 12.49 169.85 17.48C169.85 22.51 166.61 26.14 160.56 26.14L155.54 26.14L155.54 35ZM134.27 31.09C138.55 31.09 141.53 27.86 141.53 21.91C141.53 15.95 138.55 12.71 134.27 12.71C130.02 12.71 127.01 15.95 127.01 21.91C127.01 27.86 130.02 31.09 134.27 31.09ZM155.54 12.78L155.54 22.25L159.92 22.25C163.44 22.25 165.02 20.26 165.02 17.48C165.02 14.69 163.44 12.78 159.89 12.78L155.54 12.78Z" fill="#FFFFFF" fill-opacity="1.000000" fill-rule="evenodd"/>
                            <g clip-path="url(#clip6_3)">
                                <path id="path" d="M23.85 1.86L23.85 3.72L25.57 3.72L25.57 13.04L34.17 13.04L34.17 14.9L35.89 14.9L35.89 26.09L34.17 26.09L34.17 27.95L25.57 27.95L25.57 37.27L23.85 37.27L23.85 39.13L13.53 39.13L13.53 37.27L11.81 37.27L11.81 27.95L3.2 27.95L3.2 26.09L1.48 26.09L1.48 14.9L3.2 14.9L3.2 13.04L11.81 13.04L11.81 3.72L13.53 3.72L13.53 1.86L23.85 1.86ZM11.81 16.77L4.93 16.77L4.93 24.22L11.81 24.22L11.81 16.77ZM15.25 27.95L15.25 35.4L22.13 35.4L22.13 27.95L15.25 27.95Z" fill="#44FF00" fill-opacity="1.000000" fill-rule="nonzero"/>
                                <path id="path" d="M23.85 3.72L25.57 3.72L25.57 13.04L34.17 13.04L34.17 14.9L35.89 14.9L35.89 26.09L34.17 26.09L34.17 27.95L25.57 27.95L25.57 37.27L23.85 37.27L23.85 39.13L13.53 39.13L13.53 37.27L11.81 37.27L11.81 27.95L3.2 27.95L3.2 26.09L1.48 26.09L1.48 14.9L3.2 14.9L3.2 13.04L11.81 13.04L11.81 3.72L13.53 3.72L13.53 1.86L23.85 1.86L23.85 3.72ZM4.93 16.77L4.93 24.22L11.81 24.22L11.81 16.77L4.93 16.77ZM15.25 35.4L22.13 35.4L22.13 27.95L15.25 27.95L15.25 35.4Z" stroke="#44FF00" stroke-opacity="1.000000" stroke-width="0.000640"/>
                            </g>
                        </svg>
                        </div>
                       </a> 
                    </div>
                     
                    <div class="container justify-content-center">
                    <form action="search.php" method="post">
    
                        <div class="row">

                                <div class="col-md-8">
                                    
                                    <div class="input-group mb-3">
                                        

                                        
                                        <input type="text" class="form-control input-text" placeholder="Search products...." aria-label="Recipient's username" name="search" aria-describedby="basic-addon2" required>
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-warning btn-lg" type="submit"><i class="fa fa-search">
                                                <svg width="32px" height="32px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M15.7955 15.8111L21 21M18 10.5C18 14.6421 14.6421 18 10.5 18C6.35786 18 3 14.6421 3 10.5C3 6.35786 6.35786 3 10.5 3C14.6421 3 18 6.35786 18 10.5Z" stroke="#ffffff" stroke-width="0.984" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                                                </i></button>
                                        
                                            </div>
                                    
                                        
                                    </div>
                                    
                                </div>        
                                    
                        </div>
                        
                        </form>
                </div>
               
                    <div class="right">
                   
              
                        <div class="item">
                            <a href="wishlist.php">
                            <div class="icon">
                            <svg width="23.000000" height="22.000000" viewBox="0 0 23 22" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <desc>
                                        Created with Pixso.
                                </desc>
                                <defs/>
                                <path id="path" d="M15.52 0C19.39 0 22 3.91 22 7.56C22 14.94 11.19 21 11 21C10.8 21 0 14.94 0 7.56C0 3.91 2.6 0 6.47 0C8.7 0 10.15 1.19 11 2.24C11.84 1.19 13.29 0 15.52 0Z" fill="#000000" fill-opacity="0" fill-rule="nonzero"/>
                                <path id="path" d="M22 7.56C22 14.94 11.19 21 11 21C10.8 21 0 14.94 0 7.56C0 3.91 2.6 0 6.47 0C8.7 0 10.15 1.19 11 2.24C11.84 1.19 13.29 0 15.52 0C19.39 0 22 3.91 22 7.56Z" stroke="#FFFFFF" stroke-opacity="1.000000" stroke-width="0.704000" stroke-linejoin="round"/>
                            </svg>


                                    </div>
                            </a>
                        </div>

                        <div class="item">
                             <a href="profile.php"> 
                     
                            <div class="icon">
                            <svg width="25.000000" height="27.000000" viewBox="0 0 25 27" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <desc>
                                        Created with Pixso.
                                </desc>
                                <defs>
                                    <clipPath id="clip2_41">
                                        <rect id="Layer_1" width="24.923077" height="27.000000" fill="white" fill-opacity="0"/>
                                    </clipPath>
                                </defs>
                                <g clip-path="url(#clip2_41)">
                                    <ellipse id="circle" cx="12.521088" cy="7.961914" rx="5.978838" ry="6.292745" fill="#000000" fill-opacity="0"/>
                                    <ellipse id="circle" cx="12.521088" cy="7.961914" rx="5.978838" ry="6.292745" stroke="#FFFFFF" stroke-opacity="1.000000" stroke-width="0.704000"/>
                                    <path id="path" d="" fill="#000000" fill-opacity="0" fill-rule="nonzero"/>
                                    <path id="path" d="M1.56 25.78L1.95 23.53C2.17 22.23 2.61 21.01 3.24 19.87C3.87 18.73 4.67 17.73 5.64 16.89C6.61 16.04 7.68 15.4 8.86 14.95C10.04 14.5 11.26 14.27 12.52 14.27C13.77 14.27 14.99 14.5 16.18 14.95C17.36 15.4 18.43 16.05 19.4 16.9C20.36 17.75 21.16 18.74 21.8 19.88C22.43 21.03 22.86 22.25 23.09 23.55L23.47 25.8" stroke="#FFFFFF" stroke-opacity="1.000000" stroke-width="0.704000"/>
                                </g>
                            </svg>

                                    </div>
                            </a>
                        </div>

                        <div class="item">
                            <a href="card.php">
                            <div class="icon">
                            <svg width="26.000000" height="26.000000" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                <desc>
                                        Created with Pixso.
                                </desc>
                                <defs/>
                                <ellipse id="circle" cx="7.886810" cy="22.750000" rx="1.577354" ry="1.625000" fill="#FFFFFF" fill-opacity="1.000000"/>
                                <ellipse id="circle" cx="18.928192" cy="22.750000" rx="1.577354" ry="1.625000" fill="#FFFFFF" fill-opacity="1.000000"/>
                                <path id="path" d="M22.08 5.68L4.59 5.68L3.94 2.27C3.85 1.83 3.59 1.61 3.15 1.62L0 1.62L0 3.25L2.5 3.25L5.52 18.84C5.6 19.29 5.87 19.5 6.3 19.5L20.5 19.5L20.5 17.87L6.95 17.87L6.3 14.62L20.5 14.62C20.93 14.63 21.19 14.42 21.29 13.99L22.87 6.67C22.92 6.42 22.87 6.18 22.71 5.98C22.54 5.78 22.33 5.68 22.08 5.68ZM19.87 13L6 13L4.9 7.31L21.09 7.31L19.87 13Z" fill="#FFFFFF" fill-opacity="1.000000" fill-rule="nonzero"/>
                                <rect id="_Transparent_Rectangle_" width="25.237669" height="26.000000" fill="#000000" fill-opacity="0"/>
                            </svg>

                                    </div>
                            </a>
                        </div>
                        <div class="item">
                        <?php 
                        if(empty($_SESSION)){
                          echo " <div class=\"item\"><a href=\"log.php\">Вход</a></div>";
                        }else
                            {
                                echo "<form method=\"post\"><button type=\"submit\" id=\"exit_btn\" class=\"btn btn-dark\" name=\"logout\">Выйти</button></form>";
                            }
                        ?>
                        </div>
                    
                    </div>
                 </div>
        </div>