<?php 
session_start();
print_r($_SESSION);
include('webclass.php');
$sc= new SiteClass;
if(empty($_SESSION['status'])|| !isset($_SESSION['status'])){
    header("Location: index.php");
}

if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админка</title>
    <script src="assets/js/color-modes.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.js"></script>
    <link rel="stylesheet" href="assets/dist/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
     <!-- owl -->
     <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.css">
    <!--  -->
 
</head>
<body>
<?php require_once("MVC/header_admin.php"); ?>
 <div class="site_wrap">
      
 
      <h3>Добро пожаловать,Админ</h3>
      <ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Добавление товара</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Статистика</button>
  </li>
  <li class="nav-item" role="presentation">
    <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Управление товарами</button>
  </li>
</ul>
<div class="tab-content" id="myTabContent">
  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <?php
              
                if(!empty($_POST['item_name'])&&!empty($_POST['item_description'])&&!empty($_POST['item_year'])&&!empty($_FILES['item_cover']) &&!empty($_POST['site_cost'])&&!empty($_POST['off_cost'])&&!empty($_POST['item_gender'])&&!empty($_POST['item_type'])&&!empty($_FILES['item_promo_img'])&&!empty($_FILES['item_screenshots'])){
                    $item_name= $_POST['item_name'];
                    $item_description= $_POST['item_description'];
                    $item_year= $_POST['item_year'];
                    $item_cover= $_FILES['item_cover'];
                    $site_cost= $_POST['site_cost'];
                    $off_cost= $_POST['off_cost'];
                    $item_gender= $_POST['item_gender'];
                    $item_type= $_POST['item_type'];
                    $item_promo_img= $_FILES['item_promo_img'];
                    $item_screenshots= $_FILES['item_screenshots'];
                  
                 $sc->create_item($item_name,$item_description,$item_year,$item_cover,$site_cost,$off_cost,$item_gender,$item_type,$item_promo_img,$item_screenshots);
                  } 
              
                 ?>
                <h2>Добавление товара</h2>
                <form action="" method="post" enctype="multipart/form-data">
                   
            <div class="form-group">
                <label for="exampleFormControlInput1">Название</label>
                <input type="text" class="form-control" name="item_name" id="exampleFormControlInput1" placeholder="Bioshock Infinite" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlTextarea1"  >Описание товара</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" name="item_description" rows="7" placeholder="
                В 1912 году частный детектив Букер Девитт отправляется в вымышленный летающий город Колумбия в поисках девушки по имени Элизабет. 
                Там он сталкивается с войной между властями города и мятежниками. 
                Благодаря сверхъестественным способностям Элизабет создавать разрывы между параллельными мирами,
                 герои раскрывают мрачные секреты города и своего прошлого." required></textarea>

             </div>
             <div class="form-group">
                <label for="exampleFormControlInput1"  >Год выхода:</label>
                <select class="form-control" id="exampleFormControlSelect1" size="10" name="item_year" required>
                    <?php
                    
                    for($i=1995;$i<=2024;$i++){
                            echo "<option value=\"$i\">$i</option>";
                    }?>
             
                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlFile1"   >Обложка товара (200x300)</label>
                <input type="file" class="form-control-file" id="exampleFormControlFile1" name="item_cover" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1"  >Цена на сайте</label>
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="1000" name="site_cost" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlInput1"  >Оффиц. цена</label>
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="2000" name="off_cost" required>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect2"  >Выберите жанр</label>
                <div class="form-check form-switch ">
                <input class="form-check-input" type="radio" name="item_gender" value="1"  id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Экшен
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio"  name="item_gender" value="2"   id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Приключения
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio" name="item_gender" value="3"    id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Ролевые
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio" name="item_gender" value="4"   id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Стратегии
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio" name="item_gender" value="5"  id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Гонки
                </label>
                </div>
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect2"  >Выберите тип :</label>
                    <div class="form-check form-switch">
                <input class="form-check-input" type="radio" name="item_type" value="1"   id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Одиночная игра
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio"  name="item_type" value="2"   id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Локальный коорператив
                </label>
                </div>
                <div class="form-check form-switch">
                <input class="form-check-input" type="radio" name="item_type" value="3"   id="flexCheckDefault" required>
                <label class="form-check-label" for="flexCheckDefault">
                Онлайн
                </label>
                </div>
            </div>
            <div class="form-group">
                <label for="exampleFormControlFile1"  >Рекламное изображение(большое)</label>
                <input type="file" class="form-control-file" id="exampleFormControlFile1" name="item_promo_img" required>
            </div>
           
            <div class="form-group">
                <label for="exampleFormControlFile1"  >Скриншоты к товару</label>
                <input type="file" class="form-control-file" id="exampleFormControlFile1" multiple name="item_screenshots[]" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>

            </form>
           



  </div>
  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
    <?php $sc->statistic(); ?> 
  </div>
  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
</div>

<?php require_once("MVC/footer.php"); ?>

</div>
 
 <script src="js/jquery-3.7.1.js"></script>
<script src="jquery.min.js"></script>
<script src="owlcarousel/owl.carousel.min.js"></script>

 <script>
  $('.owl-carousel').owlCarousel({
    margin:10,
    loop:true,
    autoWidth:true,
    items:4,
    nav:false,
    dots:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
 </script>
</body>
</html>