<?php 
session_start();
  include('webclass.php');
$sc= new SiteClass;
if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная страница</title>
    <script src="assets/js/color-modes.js"></script>
    <script src="assets/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
     <!-- owl -->
     <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="owlcarousel/assets/owl.carousel.css">
    <!--  -->
  <style>
 
.gradient-custom {
/* fallback for old browsers */
background: #f6d365;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right bottom, rgba(246, 211, 101, 1), rgba(253, 160, 133, 1))
}
.site_wrap{
  width: 1200px;
  height: fit-content;
}
  </style>
</head>
<body>
 <div class="site_wrap">
    <?php $sc->non_index_bar(); ?>
    
    <div class="profile">
    <div class="profile_nav">
      <a href="wishlist.php">Список желаемого</a>
      <a href="wishlist.php">Корзина</a>
    </div>
      <?php 
        if(empty($_SESSION)){
          echo "
          <div class='message'> 
          <h2 style='text-align:center;'>Необходима авторизация</h2>
          <div class='links' style='text-align:center;'  > 
          <a href=\"log.php\" style='text-align:center; color: white;' >Войти</a>
          <a href=\"reg.php\" style='text-align:center; color: white;' >Регистрация</a>
          </div>
          </div>";
        }else{?>  <h2 style="text-align: center;">Список желаемого</h2>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Название</th>
      <th scope="col">Цена</th>
      <th scope="col">Скидка</th>
    </tr>
  </thead>
  <tbody>
            <?php
            $user_id=$_SESSION['id']; 
            $sc->print_user_wishlist($user_id); 
            ?>
  </tbody>
</table>
        <?}
      ?>
    </div>
   
    <?php require_once("MVC/footer.php"); ?>

 
 <script src="js/jquery-3.7.1.js"></script>
<script src="jquery.min.js"></script>
<script src="owlcarousel/owl.carousel.min.js"></script>

 <script>
  $('.owl-carousel').owlCarousel({
    margin:10,
    loop:true,
    autoWidth:true,
    items:4,
    nav:false,
    dots:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})
 </script>
</body>
</html>